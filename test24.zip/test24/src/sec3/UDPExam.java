package sec3;

public class UDPExam {
	public static void main(String[] args) {
		System.out.println("UDP : User Datagram Protocol");
		System.out.println("비연결형 프로토콜로 연결설정이 없으며 혼잡제어를 하지 않기 때문에 TCP보다 빠름");
		System.out.println("데이터전송에 대한 보장을 하지 않기 때문에 패킷손실 발생할 수 있음");
		System.out.println("DNS, 멀티미디어에서 많이 사용");
	}
}
