package sec1;

public class ChatServerExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
